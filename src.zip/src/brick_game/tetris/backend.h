#ifndef BACKEND_H
#define BACKEND_H

#include "tetris.h"
#include <ncurses.h>
#include <string.h>

static Piece current_piece;

void init_piece();
void reset_game();
void spawn_piece();
void move_piece_down();
void move_piece_left();
void move_piece_right();
void rotate_piece();
void fix_piece();
void clear_lines();
bool check_collision();
void update_score(); 
void save_high_score(); 
int load_high_score(); 
void move_piece_up();
void paused();

#endif