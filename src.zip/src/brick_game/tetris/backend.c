#include "backend.h"
#include "fsm_matrix.h"

void init_piece() {
    // Инициализация новой фигуры в верхней части экрана
    current_piece.x = WIDTH / 2 - 2;
    current_piece.y = 0;
    // Определение формы фигуры (например, квадрат 2x2)
    int new_shape[4][4] = {
        {1, 1, 0, 0},
        {1, 1, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0}
    };
    memcpy(current_piece.shape, new_shape, sizeof(new_shape));
}

void move_piece_down() {
    current_piece.y++;
}

void move_piece_left() {
    current_piece.x--;
}

void move_piece_right() {
    current_piece.x++;
}

void move_piece_up() {
    //
}

void rotate_piece() {
    int temp_shape[4][4];
    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            temp_shape[x][y] = current_piece.shape[3 - y][x];
        }
    }
    memcpy(current_piece.shape, temp_shape, sizeof(temp_shape));
}

void paused() {

}
