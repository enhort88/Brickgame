#ifndef FSM_MATRIX_H
#define FSM_MATRIX_H

#include "tetris.h"

typedef enum {
    START,
    SPAWN,
    MOVING,
    SHIFTING,
    ATTACHING,
    GAME_OVER,
    NUM_STATES
} FSMState;

static GameInfo_t game = {0};
static FSMState state = START;


UserAction_t keyboard_action(char *ch, bool *hold);
void userInput(UserAction_t action, bool hold);
void transitionState(UserAction_t action);
//static UserAction_t action = -1;
//static bool hold = false;

#endif 