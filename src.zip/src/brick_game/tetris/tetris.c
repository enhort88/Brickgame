#include "tetris.h"
#include "fsm_matrix.h"

void tetris_start(){
    while (state != GAME_OVER){
    game = updateCurrentState();
    update_field(game);
    }
}
    
    GameInfo_t updateCurrentState(){
    char ch = '\0';
    bool hold=false;
    UserAction_t action = keyboard_action(&ch, &hold);
    userInput(action, hold);
    transitionState(action);
    switch (state) {
        case SPAWN:

            break;
        case MOVING:

            break;
        case SHIFTING:

            break;
        case ATTACHING:

            break;
        default:
            break;
    }
        
return game;
}
