#include "tetris.h"

#include "../../gui/cli/frontend.h"

void tetris_start() {
  Singleton* s = get_instance();

  initialize_game();
  init_piece();
  int ch = '\0';
  int pocket = '\0';
  bool hold = false;
  clock_t last_update_time;
  int update_interval = 500;
  s->state = START;
  last_update_time = clock();
  nodelay(stdscr, TRUE);
  while (s->state != GAME_OVER) {
    clock_t current_time = clock();
    if (((current_time - last_update_time) * 10000 / CLOCKS_PER_SEC) >=
        update_interval) {
      if (!s->game.pause) {
        s->game = updateCurrentState();
        move_piece_down();
        update_field(s->game);
      }
      last_update_time = current_time;
    }
    UserAction_t action = keyboard_action(&ch, &pocket, &hold);
    userInput(action, hold);
    test_print(current_time, last_update_time, ch, action);  // del after all

    refresh();
    usleep(100);
  }
  nodelay(stdscr, FALSE);
  if (s->game.field) free_game_resources();
}

GameInfo_t updateCurrentState() {
  Singleton* s = get_instance();
  int ch = '\0';
  bool hold = false;
  int pocket = '\0';

  UserAction_t action = keyboard_action(&ch, &pocket, &hold);
  userInput(action, hold);
  transitionState(action);
  switch (s->state) {
    case SPAWN:
      init_piece();
      s->state = MOVING;
      break;
    case MOVING:

      break;
    case SHIFTING:

      break;
    case ATTACHING:

      break;
    default:
      break;
  }

  return s->game;
}
void initialize_game() {
  Singleton* s = get_instance();
  s->game.field = (int**)calloc(HEIGHT, sizeof(int*));
  if (!s->game.field) {
    perror("Failed to allocate memory for game.field");
    exit(EXIT_FAILURE);
  }
  for (int i = 0; i < HEIGHT; i++) {
    s->game.field[i] = (int*)calloc(WIDTH, sizeof(int));
    if (!s->game.field[i]) {
      perror("Failed to allocate memory for game.field[i]");
      exit(EXIT_FAILURE);
    }
  }

  s->game.score = 0;
  s->game.high_score = 0;
  s->game.level = 1;
  s->game.speed = 1;
  s->game.pause = 0;

  init_piece();
}
void test_print(clock_t current_time, clock_t last_update_time, char ch,
                UserAction_t action) {
  Singleton* s = get_instance();

  mvprintw(19, 24, "Currtime: %ld", current_time);
  mvprintw(20, 24, "LastUpT: %ld", last_update_time);
  mvprintw(21, 24, "RES: %ld",
           (current_time - last_update_time) * 10000 / CLOCKS_PER_SEC);
  mvprintw(10, 24, "ACTION:%s\tSTATE:%s", getActionName(action),
           getStateName(s->state));
  draw_key(ch);  // del
  refresh();
}

void reset_game() { exitProgram(); }