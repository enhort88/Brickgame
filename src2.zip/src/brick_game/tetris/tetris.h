#ifndef TETRIS_H
#define TETRIS_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef enum {
    Start,
    Pause,
    Terminate,
    Left,
    Right,
    Up,
    Down,
    Action
} UserAction_t;

typedef struct {
    int **field;
    int **next;
    int score;
    int high_score;
    int level;
    int speed;
    int pause;
} GameInfo_t;

typedef struct {
    int x, y; 
    int shape[4][4]; 
} Piece;

#include "backend.h"

#include "../../gui/cli/frontend.h"


#define GET_USER_INPUT getch()

static GameInfo_t game = {0};


void tetris_start();
GameInfo_t updateCurrentState();
void initialize_game();
#endif 