#include "fsm_matrix.h"

FSMState transitionMatrix[NUM_STATES][8] = {
    [START] = {[Start] = SPAWN,
               [Terminate] = GAME_OVER,
               [Pause] = START,
               [Left] = START,
               [Right] = START,
               [Up] = START,
               [Down] = START,
               [Action] = START},
    [SPAWN] = {[Action] = MOVING,
               [Terminate] = GAME_OVER,
               [Pause] = SPAWN,
               [Left] = SPAWN,
               [Right] = SPAWN,
               [Up] = SPAWN,
               [Down] = SPAWN,
               [Start] = SPAWN},
    [MOVING] = {[Action] = SHIFTING,
                [Terminate] = GAME_OVER,
                [Pause] = MOVING,
                [Left] = MOVING,
                [Right] = MOVING,
                [Up] = MOVING,
                [Down] = MOVING,
                [Start] = MOVING},
    [SHIFTING] = {[Action] = SHIFTING,
                  [Terminate] = GAME_OVER,
                  [Pause] = SHIFTING,
                  [Left] = MOVING,
                  [Right] = MOVING,
                  [Up] = MOVING,
                  [Down] = MOVING,
                  [Start] = START},
    [ATTACHING] = {[Action] = SPAWN,
                   [Terminate] = GAME_OVER,
                   [Pause] = ATTACHING,
                   [Left] = ATTACHING,
                   [Right] = ATTACHING,
                   [Up] = ATTACHING,
                   [Down] = ATTACHING,
                   [Start] = ATTACHING},
    [GAME_OVER] = {[Action] = GAME_OVER,
                   [Terminate] = GAME_OVER,
                   [Pause] = GAME_OVER,
                   [Left] = GAME_OVER,
                   [Right] = GAME_OVER,
                   [Up] = GAME_OVER,
                   [Down] = GAME_OVER,
                   [Start] = START}};

void userInput(UserAction_t action, bool hold) {

    switch (action) {
      case Left:
        move_piece_left();
        break;
      case Right:
        move_piece_right();
        break;
      case Down:
        move_piece_down();
        break;
      case Up:
        move_piece_up();
        break;
      case Action:
        rotate_piece();
        break;
      case Pause:
        game.pause = !game.pause;
        break;
      case Start:
        tetris_start();
        break;
      case Terminate:
        exitProgram();
        // reset_game();
        break;
    }
  
}

UserAction_t keyboard_action(char *ch, bool *hold) {
  char pocket = '\0';

    *ch = GET_USER_INPUT;
    *hold = (pocket == *ch) ? true : false;
    pocket = *ch;
    switch (*ch) {
      case KEY_LEFT:
        return Left;
      case KEY_RIGHT:
        return Right;
      case KEY_DOWN:
        return Down;
      case KEY_UP:
        return Up;
      case ' ':
        return Action;
      case 'p':
        return Pause;
      case 's':
        return Start;
      case 'q':
        return Terminate;
    }
}
void transitionState(UserAction_t action) {
  if (action < 0 || action >= 8) {
    return;
  }
  state = transitionMatrix[state][action];
}