#include "tetris.h"

#include "fsm_matrix.h"

static clock_t last_update_time;
void tetris_start() {
  
  int update_interval = 500;
  FSMState state = START;
  GameInfo_t game;
  Piece current_piece;
  initialize_game();
  while (state != GAME_OVER) {
    clock_t current_time = clock();
    if (((current_time - last_update_time) * 1000 / CLOCKS_PER_SEC) >=
        update_interval) {
      if (!game.pause) {
        game = updateCurrentState();
        move_piece_down();  // автоматическое движение вниз
        update_field(game);
      }
      last_update_time = current_time;
    }
  char ch = '\0';
  bool hold = false;
        UserAction_t action = keyboard_action(&ch, &hold);
        userInput(action, hold); // Обработка ввода пользователя
  }
}

GameInfo_t updateCurrentState() {
  char ch = '\0';
  bool hold = false;
  UserAction_t action = keyboard_action(&ch, &hold);
  userInput(action, hold);
  transitionState(action);
  switch (state) {
    case SPAWN:
      init_piece();
      state = MOVING;
      break;
    case MOVING:

      break;
    case SHIFTING:

      break;
    case ATTACHING:

      break;
    default:
      break;
  }

  return game;
}
void initialize_game() {
  game.field = (int **)malloc(HEIGHT * sizeof(int *));
  for (int i = 0; i < HEIGHT; i++) {
    game.field[i] = (int *)malloc(WIDTH * sizeof(int));
    for (int j = 0; j < WIDTH; j++) {
      game.field[i][j] = 0;
    }
  }
  game.score = 0;
  game.high_score = 0;
  game.level = 1;
  game.speed = 1;
  game.pause = 0;

  init_piece();
  last_update_time = clock();
}
