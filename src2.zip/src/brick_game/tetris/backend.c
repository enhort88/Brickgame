#include "backend.h"

#include "fsm_matrix.h"

void init_piece() {
  // Инициализация новой фигуры в верхней части экрана
  current_piece.x = WIDTH / 2 - 2;
  current_piece.y = 0;
  // Определение формы фигуры (например, квадрат 2x2)
  int new_shape[4][4] = {
      {1, 1, 0, 0}, {1, 1, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
  memcpy(current_piece.shape, new_shape, sizeof(new_shape));
}

void move_piece_down() {
  current_piece.y++;
  if (check_collision()) {
    current_piece.y--;
    state = ATTACHING;
    // Присоединение фигуры к полю и проверка на завершенные линии
    attach_piece_to_field();
    check_for_complete_lines();
    state = SPAWN;
  }
}

void move_piece_left() { current_piece.x--; }

void move_piece_right() { current_piece.x++; }

void move_piece_up() {
  //
}

void rotate_piece() {
  int temp_shape[4][4];
  for (int y = 0; y < 4; y++) {
    for (int x = 0; x < 4; x++) {
      temp_shape[x][y] = current_piece.shape[3 - y][x];
    }
  }
  memcpy(current_piece.shape, temp_shape, sizeof(temp_shape));
}



bool check_collision() {
  // Добавьте логику для проверки столкновений
  return false;
}
void attach_piece_to_field() {
  for (int y = 0; y < 4; y++) {
    for (int x = 0; x < 4; x++) {
      if (current_piece.shape[y][x] != 0) {
        game.field[current_piece.y + y][current_piece.x + x] =
            current_piece.shape[y][x];
      }
    }
  }
}

void check_for_complete_lines() {
  for (int y = 0; y < HEIGHT; y++) {
    bool complete = true;
    for (int x = 0; x < WIDTH; x++) {
      if (game.field[y][x] == 0) {
        complete = false;
        break;
      }
    }
    if (complete) {
      // Удаление линии и обновление счета
      clear_lines(y);
      game.score += 100;  // Пример обновления счета
    }
  }
}
void clear_lines(int line) {
  for (int y = line; y > 0; y--) {
    for (int x = 0; x < WIDTH; x++) {
      game.field[y][x] = game.field[y - 1][x];
    }
  }
  for (int x = 0; x < WIDTH; x++) {
    game.field[0][x] = 0;
  }
}