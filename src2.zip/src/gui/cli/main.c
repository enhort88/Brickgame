#include <ncurses.h>

#include "../../brick_game/tetris/tetris.h"
#include "frontend.h"

int main() {
  initscr();
  keypad(stdscr, TRUE);
  noecho();
  cbreak();
  curs_set(0);            // ?
  nodelay(stdscr, TRUE);  // Не блокировать при вызове getch
  main_menu_init();
  if (game.field) free_game_resources();  // todo
  endwin();
  return 0;
}
