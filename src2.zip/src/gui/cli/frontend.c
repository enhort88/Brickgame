#include "frontend.h"

void main_menu_init() {
  clear();
  draw_board();
  draw_score(0, 0, 0);
  int choice = 0;
  int ch;
  char *choices[] = {"Tetris", "Quit"};
  int n_choices = sizeof(choices) / sizeof(char *);

  while (true) {
    int menu_start_x = (WIDTH * 2) / 2 - 3;
    int menu_start_y = HEIGHT / 2 - n_choices / 2;
    for (int i = 0; i < n_choices; ++i) {
      if (i == choice) attron(A_REVERSE);
      mvprintw(menu_start_y + i, menu_start_x, "%s", choices[i]);
      if (i == choice) attroff(A_REVERSE);
    }
    refresh();
    ch = GET_USER_INPUT;
    switch (ch) {
      case KEY_UP:
        choice = (choice == 0) ? n_choices - 1 : choice - 1;
        break;
      case KEY_DOWN:
        choice = (choice == n_choices - 1) ? 0 : choice + 1;
        break;
      case 10:
        if (choice == 0) {
          play_tetris();
        } else if (choice == 1) {
          exitProgram();
        }
        return;
    }
  }
}

void play_tetris() {
  init_piece();
  clear();
  int menu_start_x = (WIDTH * 2) / 2 - 3;
  int menu_start_y = HEIGHT / 2 - 2 / 2;
  draw_board();
  draw_field();
  draw_score(0, 0, 0);
  mvprintw(menu_start_y, menu_start_x - 1, "Tetris game");
  mvprintw(menu_start_y + 1, menu_start_x - 5, "Press \"S\" for Start");
  tetris_start();
}

void exitProgram() {
  if (game.field) free_game_resources();
  clear();
  endwin();
  exit(0);
}

void update_field(GameInfo_t game) {
  clear();
  draw_board();
  // draw_field();
  draw_score(game.score, game.high_score, game.level);
  draw_piece(current_piece);
  refresh();
}
void draw_field() {
  for (int y = 0; y < HEIGHT; y++) {
    for (int x = 0; x < WIDTH; x++) {
      if (game.field[y][x] == 0) {
        mvprintw(y + 1, x * 2 + 1, ".");
      } else {
        mvprintw(y + 1, x * 2 + 1, "[]");
      }
    }
  }
  refresh();
}
void draw_score(int score, int high_score, int level) {
  int info_start_x = WIDTH * 2 + 4;
  // if (high_score < score) high_score = score;

  mvprintw(0, info_start_x, "Score:%d", score);
  mvprintw(2, info_start_x, "High Score:%d", high_score);
  mvprintw(4, info_start_x, "Level:%d", level);
  refresh();
}

void draw_board() {
  for (int y = 0; y < HEIGHT + 2; y++) {
    for (int x = 0; x < WIDTH * 2 + 2; x++) {
      if (y == 0 || y == HEIGHT + 1 || x == 0 || x == WIDTH * 2 + 1) {
        mvprintw(y, x, "#");
      }
    }
  }
}
void draw_next(GameInfo_t game) {
  for (int y = 0; y < HEIGHT + 2; y++) {
    for (int x = 0; x < WIDTH * 2 + 2; x++) {
      if (y == 0 || y == HEIGHT + 1 || x == 0 || x == WIDTH * 2 + 1) {
        mvprintw(y, x, "#");
      }
    }
  }
}
void draw_piece(Piece piece) {
  for (int y = 0; y < 4; y++) {
    for (int x = 0; x < 4; x++) {
      if (piece.shape[y][x] != 0) {
        mvprintw(piece.y + y + 1, (piece.x + x) * 2 + 1, "[]");
      }
    }
  }
  refresh();
}
void free_game_resources() {
  for (int i = 0; i < HEIGHT; i++) {
  free(game.field[i]);
  }
  free(game.field);
}